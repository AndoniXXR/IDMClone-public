// IDMClone Integration — fondo de la extensión.
// Chrome/Edge/Brave/Opera/Vivaldi: service worker (Manifest V3). Firefox: página de fondo (scripts).
// Captura descargas del navegador y las envía a IDMClone por el host de mensajería nativa
// com.idmclone.host. Solo usa las APIs que el navegador da a las extensiones: nada de drivers
// ni de interceptar el tráfico de otras aplicaciones.
"use strict";
if (typeof importScripts === "function" && typeof self.IDMLogic === "undefined") importScripts("logic.js");

const L = self.IDMLogic;
const B = (typeof browser !== "undefined" && browser.runtime) ? browser : chrome;
const HOST = "com.idmclone.host";
const DOWNLOAD_REPLY_MS = 25000; // con IDMClone cerrado, el host lo arranca y espera su respuesta
const PING_REPLY_MS = 5000;
const DEFAULTS = { enabled: true, exts: L.DEFAULT_EXTS, minSizeKB: 0, exclude: L.DEFAULT_EXCLUDE };

// Tipos de archivo y sitios excluidos: los de IDMClone (Opciones > Tipos de archivo), como hace IDM.
// Se piden al host y se guardan un minuto; si el host no está, se usan los últimos conocidos o los propios.
const APP_CFG_TTL_MS = 60000;
let appCfg = null, appCfgAt = 0;

let appCfgPending = null;

function getAppConfig() {
  if (appCfg && Date.now() - appCfgAt < APP_CFG_TTL_MS) return Promise.resolve(appCfg);
  if (!appCfgPending) appCfgPending = fetchAppConfig().finally(() => { appCfgPending = null; });
  return appCfgPending;
}

async function fetchAppConfig() {
  const r = await hostRequest({ type: "getconfig" }, PING_REPLY_MS);
  if (r && r.ok && Array.isArray(r.exts)) {
    appCfg = { exts: r.exts, exclude: Array.isArray(r.exclude) ? r.exclude : [],
               preventKeys: typeof r.preventKeys === "string" ? r.preventKeys : "del", forceKeys: r.forceKeys || "",
               mediaPanel: r.mediaPanel !== false, mediaMini: !!r.mediaMini, mediaExclude: Array.isArray(r.mediaExclude) ? r.mediaExclude : [],
               minVideoKB: r.minVideoKB || 0, minAudioKB: r.minAudioKB || 0 };
    appCfgAt = Date.now();
    try { await B.storage.local.set({ appCfg }); } catch (e) { }
  } else if (!appCfg) {
    try { appCfg = (await B.storage.local.get({ appCfg: null })).appCfg; } catch (e) { }
    appCfgAt = Date.now() - APP_CFG_TTL_MS + 5000; // reintentar pronto
  }
  return appCfg;
}

async function getSettings() {
  const s = await B.storage.local.get(DEFAULTS);
  if (!Array.isArray(s.exts) || s.exts.length === 0) s.exts = L.DEFAULT_EXTS;
  if (!Array.isArray(s.exclude)) s.exclude = L.DEFAULT_EXCLUDE;
  const a = await getAppConfig();
  if (a && a.exts && a.exts.length) { s.exts = a.exts; s.exclude = a.exclude || []; s.fromApp = true; }
  return s;
}

// ---------------------------------------------------------------------------------------------
// Canal persistente con el host nativo (un solo proceso para muchas peticiones). Cada petición
// lleva un "rid" y el host lo devuelve en la respuesta. Si el canal se cae, se reabre en la siguiente.
let port = null;
let nextRid = 1;
const pending = new Map();

function connect() {
  if (port) return port;
  const p = B.runtime.connectNative(HOST);
  p.onMessage.addListener((msg) => {
    const w = msg && pending.get(msg.rid);
    if (!w) return;
    pending.delete(msg.rid);
    clearTimeout(w.timer);
    w.resolve(msg);
  });
  p.onDisconnect.addListener(() => {
    const e = (p.error && p.error.message) || (B.runtime.lastError && B.runtime.lastError.message) || "el host se cerró";
    if (port === p) port = null;
    for (const [rid, w] of pending) { clearTimeout(w.timer); w.resolve({ ok: false, error: "Host nativo no disponible: " + e + ". ¿Ejecutaste install.ps1?" }); }
    pending.clear();
  });
  port = p;
  return p;
}

function hostRequest(msg, timeoutMs) {
  return new Promise((resolve) => {
    let p;
    try { p = connect(); } catch (e) { resolve({ ok: false, error: "Host nativo no disponible: " + (e && e.message || e) }); return; }
    const rid = nextRid++;
    const timer = setTimeout(() => { pending.delete(rid); resolve({ ok: false, error: "IDMClone no respondió a tiempo." }); }, timeoutMs);
    pending.set(rid, { resolve, timer });
    try { p.postMessage(Object.assign({ rid }, msg)); }
    catch (e) { pending.delete(rid); clearTimeout(timer); if (port === p) port = null; resolve({ ok: false, error: String(e && e.message || e) }); }
  });
}

// ---------------------------------------------------------------------------------------------
// Cabeceras de las respuestas (Content-Type/Disposition/Length): el navegador no siempre las da
// en la API de descargas, y sin ellas un "descargar.php?id=5" no se reconocería.
const headerCache = new Map();
const HEADER_TTL_MS = 60000;

function rememberHeaders(details) {
  const h = {};
  for (const x of details.responseHeaders || []) {
    const n = (x.name || "").toLowerCase();
    if (n === "content-type") h.contentType = x.value;
    else if (n === "content-disposition") h.contentDisposition = x.value;
    else if (n === "content-length") h.contentLength = parseInt(x.value, 10) || 0;
  }
  const ct = (h.contentType || "").toLowerCase();
  const interesting = h.contentDisposition || (ct && !/^(text\/|image\/(png|gif|jpeg|webp|svg)|application\/(json|javascript|xml))/.test(ct));
  if (!interesting) return;
  h.t = Date.now();
  headerCache.set(details.url, h);
  if (headerCache.size > 300) {
    const now = Date.now();
    for (const [k, v] of headerCache) if (now - v.t > HEADER_TTL_MS || headerCache.size > 200) headerCache.delete(k);
  }
}

function headersFor(...urls) {
  for (const u of urls) {
    const h = u && headerCache.get(u);
    if (h && Date.now() - h.t < HEADER_TTL_MS) return h;
  }
  return {};
}

if (B.webRequest && B.webRequest.onHeadersReceived) {
  try {
    B.webRequest.onHeadersReceived.addListener(rememberHeaders,
      { urls: ["<all_urls>"], types: ["main_frame", "sub_frame", "other", "xmlhttprequest", "media", "object"] },
      ["responseHeaders"]);
  } catch (e) { console.warn("IDMClone: sin webRequest", e); }
}

// ---------------------------------------------------------------------------------------------
// Formularios (POST): algunas descargas solo las da el sitio tras enviar un formulario. Se guarda el
// cuerpo enviado para que IDMClone pueda repetir la misma petición (como hace IDM).
const postBodies = new Map();
const POST_TTL_MS = 120000;

function rememberPost(details) {
  if (details.method !== "POST" || !details.requestBody) return;
  let data = null;
  const fd = details.requestBody.formData;
  if (fd) {
    const parts = [];
    for (const k of Object.keys(fd)) for (const v of fd[k]) parts.push(encodeURIComponent(k) + "=" + encodeURIComponent(v));
    data = parts.join("&");
  } else if (details.requestBody.raw && details.requestBody.raw.length === 1 && details.requestBody.raw[0].bytes) {
    const bytes = details.requestBody.raw[0].bytes;
    if (bytes.byteLength <= 65536) { try { data = new TextDecoder("utf-8", { fatal: true }).decode(bytes); } catch (e) { data = null; } }
  }
  if (data === null) return;
  postBodies.set(details.url, { data, t: Date.now() });
  if (postBodies.size > 50) postBodies.delete(postBodies.keys().next().value);
}

function postFor(...urls) {
  for (const u of urls) {
    const p = u && postBodies.get(u);
    if (p && Date.now() - p.t < POST_TTL_MS) return p.data;
  }
  return "";
}

if (B.webRequest && B.webRequest.onBeforeRequest) {
  try {
    B.webRequest.onBeforeRequest.addListener(rememberPost, { urls: ["<all_urls>"], types: ["main_frame", "sub_frame"] }, ["requestBody"]);
  } catch (e) { console.warn("IDMClone: sin requestBody", e); }
}

// ---------------------------------------------------------------------------------------------
// Panel "Descargar este video" (como IDM): cuando la página reproduce un vídeo o un audio (archivo,
// lista HLS .m3u8 o DASH .mpd), se avisa a la página (content.js) para que muestre el panel encima
// del reproductor. Las calidades de HLS/DASH las lee IDMClone (mensaje "probe" del host nativo).
const tabMedia = new Map(); // tabId -> { items: Map(url -> entrada), children: Set(listas de cada calidad) }
const PROBE_REPLY_MS = 20000;
let mediaSeq = 1;

function mediaState(tabId) {
  let s = tabMedia.get(tabId);
  if (!s) { s = { items: new Map(), children: new Set() }; tabMedia.set(tabId, s); }
  return s;
}

function header(details, name) {
  for (const x of details.responseHeaders || []) if ((x.name || "").toLowerCase() === name) return x.value;
  return "";
}

async function detectMedia(details) {
  if (details.tabId < 0) return;
  const m = L.classifyMedia({ url: details.url, type: details.type, statusCode: details.statusCode,
    contentType: header(details, "content-type"), contentLength: parseInt(header(details, "content-length"), 10) || 0,
    contentRange: header(details, "content-range") });
  if (!m) return;
  const st = mediaState(details.tabId);
  const key = (m.url || details.url).split("#")[0];
  if (st.items.has(key) || st.children.has(key)) return;
  // Trozos de un archivo cuando la página ya tiene su lista HLS/DASH: son de esa lista.
  if (m.ranged && [...st.items.values()].some((e) => e && e.kind !== "file" && e.kind !== "pair")) return;
  st.items.set(key, null); // en curso: no preguntar dos veces por la misma lista
  const cfg = (await getAppConfig()) || {};
  let tab = null;
  try { tab = await B.tabs.get(details.tabId); } catch (e) { }
  const page = (tab && tab.url) || details.documentUrl || details.initiator || "";
  if (cfg.mediaPanel === false || (cfg.mediaExclude && L.urlExcluded(page, cfg.mediaExclude))) return;

  let entry;
  if (m.kind === "file") {
    const minKB = m.media === "audio" ? (cfg.minAudioKB || 0) : (cfg.minVideoKB || 0);
    // Más pequeño que el mínimo: no se ofrece solo; pero el audio de un vídeo pedido a trozos se guarda
    // (sin enseñarlo) para poder juntarlo con su vídeo.
    const small = m.size > 0 && m.size < minKB * 1024;
    if (small && !m.ranged) return;
    const url = m.url || details.url;
    const ext = "." + (L.extOf(url) || (m.media === "audio" ? (m.ranged ? "m4a" : "mp3") : "mp4"));
    entry = { id: mediaSeq++, kind: "file", url, media: m.media, ranged: !!m.ranged, t: Date.now(), hidden: small,
              items: [{ kind: m.media, ext, size: m.size }] };
    // Vídeo y audio en archivos aparte (el reproductor pide los dos a trozos): se ofrecen juntos, y
    // IDMClone los mezcla en un archivo (como IDM con Facebook o Instagram).
    if (m.ranged) {
      const other = [...st.items.values()].filter((e) => e && e.kind === "file" && e.ranged && e.media !== m.media && Date.now() - e.t < 120000).pop();
      if (other) {
        st.items.set(key, entry);
        if (m.media === "audio") {
          // El audio sirve para todas las calidades de vídeo vistas: un par por cada una.
          for (const e of [...st.items.values()]) if (e && e.kind === "file" && e.ranged && e.media === "video" && !e.hidden) await sendPair(details, st, e, entry);
          return;
        }
        if (m.media === "video" && small) return; // vídeo demasiado pequeño (anuncio...): ni solo ni con audio
        await sendPair(details, st, entry, other);
        return;
      }
      if (small) { st.items.set(key, entry); return; }
    }
  } else {
    let cookies = "";
    try { cookies = await gatherCookies(details.url, tab && tab.incognito); } catch (e) { }
    const r = await hostRequest({ type: "probe", url: details.url, cookies, referrer: page, userAgent: navigator.userAgent }, PROBE_REPLY_MS);
    if (!r || !r.ok) { st.items.delete(key); return; }
    // Las listas de cada calidad no son vídeos aparte. El reproductor pudo pedir alguna mientras
    // IDMClone leía la maestra: se quitan del panel.
    for (const c of r.children || []) {
      const ck = c.split("#")[0];
      st.children.add(ck);
      const old = st.items.get(ck);
      st.items.delete(ck);
      if (old) { try { await B.tabs.sendMessage(details.tabId, { type: "idm-media-remove", url: old.url }); } catch (e) { } }
    }
    if (st.children.has(key)) { st.items.delete(key); return; } // resultó ser una calidad de otra lista
    if (!r.items || !r.items.length) return;
    // En directo también (se graba, como IDM).
    entry = { id: mediaSeq++, kind: r.kind, url: details.url, duration: r.duration, protected: !!r.protected, live: !!r.live,
              media: r.items.some((i) => i.kind === "video") ? "video" : "audio", items: r.items };
    // Trozos de archivos que ya se ofrecían sueltos: eran de esta lista.
    for (const [k, e] of [...st.items.entries()]) if (e && e.ranged) { st.items.delete(k); await removeEntry(details, e); }
  }
  st.items.set(key, entry);
  // Al marco que lo pidió (el del reproductor); si no tiene content.js (about:blank...), a la página.
  const send = (frameId) => B.tabs.sendMessage(details.tabId, { type: "idm-media", entry }, { frameId });
  try { await send(details.frameId > 0 ? details.frameId : 0); }
  catch (e) { if (details.frameId > 0) { try { await send(0); } catch (e2) { } } }
}

if (B.webRequest && B.webRequest.onHeadersReceived) {
  try {
    B.webRequest.onHeadersReceived.addListener((d) => { detectMedia(d).catch(() => {}); },
      { urls: ["<all_urls>"], types: ["sub_frame", "other", "xmlhttprequest", "media", "object"] }, ["responseHeaders"]);
  } catch (e) { console.warn("IDMClone: sin detección de vídeo", e); }
}
if (B.tabs && B.tabs.onUpdated) {
  B.tabs.onUpdated.addListener((tabId, info) => { if (info.status === "loading" && info.url) tabMedia.delete(tabId); });
  B.tabs.onRemoved.addListener((tabId) => tabMedia.delete(tabId));
}

async function removeEntry(details, e) {
  try { await B.tabs.sendMessage(details.tabId, { type: "idm-media-remove", url: e.url }); } catch (x) { }
}

// Un par vídeo + audio (los sueltos se quitan del panel).
async function sendPair(details, st, v, a) {
  const vext = v.items[0].ext === ".webm" ? ".webm" : ".mp4";
  const size = v.items[0].size > 0 && a.items[0].size > 0 ? v.items[0].size + a.items[0].size : -1;
  const pairKey = "pair:" + v.url;
  const old = st.items.get(pairKey);
  if (old) await removeEntry(details, old);
  for (const e of [v, a]) await removeEntry(details, e);
  const entry = { id: mediaSeq++, kind: "pair", url: v.url, media: "video",
                  items: [{ kind: "video", video: v.url, audio: a.url, ext: vext, size }] };
  st.items.set(pairKey, entry);
  const send = (frameId) => B.tabs.sendMessage(details.tabId, { type: "idm-media", entry }, { frameId });
  try { await send(details.frameId > 0 ? details.frameId : 0); }
  catch (e) { if (details.frameId > 0) { try { await send(0); } catch (e2) { } } }
}

// El usuario eligió una calidad en el panel.
async function downloadMedia(entry, item, tab) {
  const title = (tab && tab.title) || "";
  const filename = L.mediaFileName(title || "video", item.ext || ".mp4");
  const incognito = !!(tab && tab.incognito);
  const referrer = (tab && tab.url) || "";
  if (entry.kind === "file") return sendToIdm({ url: entry.url, referrer, filename, incognito });
  let cookies = "";
  try { cookies = await gatherCookies(entry.url, incognito); } catch (e) { }
  return hostRequest({ type: "download", url: item.video && entry.kind === "pair" ? item.video : entry.url, referrer, cookies, filename,
                       userAgent: navigator.userAgent, incognito,
                       mediaKind: entry.kind, mediaVideo: item.video || "", mediaAudio: item.audio || "" }, DOWNLOAD_REPLY_MS);
}

// Tecla "para no descargar con IDMClone" pulsada al hacer clic (content.js): esa descarga sigue en el navegador.
const prevented = new Map();
const PREVENT_MS = 8000;

function isPrevented(item) {
  const now = Date.now();
  for (const [u, p] of prevented) {
    if (now - p.t > PREVENT_MS) { prevented.delete(u); continue; }
    if (u === item.url || u === item.finalUrl) return true;
    // El enlace pudo redirigir: vale también si viene de la misma página en los segundos siguientes.
    if (p.referrer && item.referrer === p.referrer && now - p.t < 3000) return true;
  }
  return false;
}

// ---------------------------------------------------------------------------------------------
// Cookies del sitio, del almacén correcto (normal o incógnito).
async function gatherCookies(url, incognito) {
  const q = { url };
  if (incognito && B.cookies.getAllCookieStores) {
    try {
      const stores = await B.cookies.getAllCookieStores();
      const priv = stores.find((s) => s.incognito) || stores.find((s) => s.id === "1" || s.id === "firefox-private");
      if (priv) q.storeId = priv.id;
    } catch (e) { }
  }
  const all = await B.cookies.getAll(q);
  return (all || []).map((c) => c.name + "=" + c.value).join("; ");
}

async function sendToIdm(info) {
  let cookies = "";
  try { cookies = await gatherCookies(info.url, info.incognito); } catch (e) { }
  return hostRequest({
    type: "download",
    url: info.url,
    referrer: info.referrer || "",
    cookies,
    filename: info.filename || "",
    userAgent: navigator.userAgent,
    incognito: !!info.incognito,
    size: info.size || 0,
    postData: info.postData || ""
  }, DOWNLOAD_REPLY_MS);
}

function notify(title, message) {
  try {
    B.notifications.create("", { type: "basic", iconUrl: "icons/icon48.png", title, message: String(message || "").substring(0, 200) });
  } catch (e) { }
}

// ---------------------------------------------------------------------------------------------
// Captura automática. En Chromium se decide en onDeterminingFilename (ya se conoce el nombre final
// del servidor); en Firefox, en onCreated (allí ya viene). La descarga se PAUSA mientras IDMClone
// confirma: si la acepta se cancela en el navegador; si no, se reanuda y sigue allí (como IDM).
const decided = new Set();
const waitingName = new Map();
const prePaused = new Set();
const hasDetermining = !!(B.downloads && B.downloads.onDeterminingFilename);

// ¿Podría ser para IDMClone? Se decide antes de conocer el nombre final: si la URL ya dice que es
// un tipo no vigilado (p. ej. foto.png con image/png) no hace falta pausar; si no está claro, sí.
async function mightCapture(item) {
  const s = await getSettings();
  const dec = L.decide({ url: item.url, finalUrl: item.finalUrl, mime: item.mime, totalBytes: item.totalBytes,
                         byExtensionId: item.byExtensionId, ownId: B.runtime.id }, s);
  if (dec.capture) return true;
  if (dec.reason.indexOf("tipo no vigilado") !== 0) return false; // desactivada, esquema, sitio excluido...
  const mime = String(item.mime || "").toLowerCase();
  const genericMime = !mime || mime === "application/octet-stream" || mime === "application/force-download" || mime === "binary/octet-stream";
  return !dec.ext || L.extOf(item.url) === "" || genericMime;
}

function markDecided(id) {
  decided.add(id);
  if (decided.size > 500) decided.delete(decided.values().next().value);
}

async function consider(item) {
  if (decided.has(item.id)) return { capture: false, reason: "ya decidida" };
  markDecided(item.id);
  if (item.state && item.state !== "in_progress") return { capture: false, reason: "no está en curso" };

  const s = await getSettings();
  const hdr = headersFor(item.finalUrl, item.url);
  const dec = L.decide({
    url: item.url, finalUrl: item.finalUrl, filename: item.filename, mime: item.mime || hdr.contentType,
    totalBytes: item.totalBytes > 0 ? item.totalBytes : (item.fileSize > 0 ? item.fileSize : (hdr.contentLength || 0)),
    contentDisposition: hdr.contentDisposition, byExtensionId: item.byExtensionId, ownId: B.runtime.id
  }, s);
  const wasPrePaused = prePaused.delete(item.id);
  if (dec.capture && isPrevented(item)) { dec.capture = false; dec.reason = "tecla para no descargar con IDMClone"; }
  if (!dec.capture) {
    // Se pausó por si acaso y al final no es para IDMClone: sigue en el navegador.
    if (wasPrePaused) { try { await B.downloads.resume(item.id); } catch (e) { } }
    return dec;
  }

  let paused = wasPrePaused;
  if (!paused) { try { await B.downloads.pause(item.id); paused = true; } catch (e) { } }

  const r = await sendToIdm({
    url: item.url || item.finalUrl, referrer: item.referrer, filename: dec.name,
    incognito: item.incognito, size: item.totalBytes > 0 ? item.totalBytes : 0,
    postData: postFor(item.url, item.finalUrl)
  });

  if (r && r.ok) {
    try { await B.downloads.cancel(item.id); } catch (e) { }
    // Si el navegador llegó a terminarla antes de cancelar, borrar su copia: ya la tiene IDMClone.
    try {
      const now = await B.downloads.search({ id: item.id });
      if (now && now[0] && now[0].state === "complete" && now[0].exists !== false) await B.downloads.removeFile(item.id);
    } catch (e) { }
    try { await B.downloads.erase({ id: item.id }); } catch (e) { }
    notify("Enviado a IDMClone", dec.name || item.url);
    dec.sent = true;
  } else {
    if (paused) { try { await B.downloads.resume(item.id); } catch (e) { } }
    notify("La descarga sigue en el navegador", (r && r.error) || "IDMClone no está disponible.");
    dec.sent = false;
    dec.error = r && r.error;
  }
  return dec;
}

B.downloads.onCreated.addListener(async (item) => {
  if (hasDetermining && !item.filename) {
    // Esperar al nombre definitivo; si el navegador no lo da (otra extensión, etc.), decidir igual.
    // Mientras tanto, pausar si puede ser para IDMClone: el navegador no avanza mientras se decide.
    waitingName.set(item.id, item);
    setTimeout(() => { const it = waitingName.get(item.id); if (it) { waitingName.delete(item.id); consider(it); } }, 2000);
    try {
      if (await mightCapture(item) && waitingName.has(item.id) && !decided.has(item.id)) {
        prePaused.add(item.id);
        await B.downloads.pause(item.id);
      }
    } catch (e) { prePaused.delete(item.id); }
    return;
  }
  consider(item);
});

if (hasDetermining) {
  B.downloads.onDeterminingFilename.addListener((item, suggest) => {
    suggest(); // el nombre lo decide el navegador; solo lo leemos
    const base = waitingName.get(item.id);
    waitingName.delete(item.id);
    consider(Object.assign({}, base || {}, item));
  });
}

// --- Menú contextual: "Descargar con IDMClone" ---
function createMenus() {
  Promise.resolve(B.contextMenus.removeAll()).then(() => {
    B.contextMenus.create({ id: "idmclone-link", title: "Descargar con IDMClone", contexts: ["link"] });
    B.contextMenus.create({ id: "idmclone-media", title: "Descargar con IDMClone", contexts: ["image", "video", "audio"] });
    B.contextMenus.create({ id: "idmclone-all", title: "Descargar todos los enlaces con IDMClone", contexts: ["page"] });
    B.contextMenus.create({ id: "idmclone-selected", title: "Descargar los enlaces seleccionados con IDMClone", contexts: ["selection"] });
  });
}
B.runtime.onInstalled.addListener(createMenus);

// Recoge los enlaces de la página (o de la selección): <a href>, imágenes, vídeo y audio.
// Se ejecuta DENTRO de la página, solo cuando el usuario elige la opción del menú.
function collectLinks(selectionOnly) {
  const out = [];
  const seen = new Set();
  const sel = selectionOnly ? window.getSelection() : null;
  const inSel = (el) => !sel || (sel.rangeCount > 0 && sel.containsNode(el, true));
  const add = (url, text) => {
    if (!url || !/^(https?|ftps?):/i.test(url) || seen.has(url)) return;
    seen.add(url);
    out.push({ url, text: (text || "").replace(/\s+/g, " ").trim().substring(0, 200) });
  };
  for (const a of document.querySelectorAll("a[href]")) if (inSel(a)) add(a.href, a.innerText || a.title);
  for (const m of document.querySelectorAll("img[src], video[src], audio[src], source[src]")) if (inSel(m)) add(m.src, m.alt || m.title);
  return out;
}

async function sendLinks(tab, selectionOnly) {
  let links = [];
  try {
    const res = await B.scripting.executeScript({ target: { tabId: tab.id }, func: collectLinks, args: [!!selectionOnly] });
    links = (res && res[0] && res[0].result) || [];
  } catch (e) {
    notify("IDMClone", "No se pueden leer los enlaces de esta página: " + (e && e.message || e));
    return null;
  }
  if (!links.length) { notify("IDMClone", selectionOnly ? "La selección no tiene enlaces." : "La página no tiene enlaces."); return null; }
  // Cookies de cada servidor (las necesitan los enlaces que piden sesión).
  const cookies = {};
  for (const host of [...new Set(links.map((l) => { try { return new URL(l.url).host; } catch (e) { return ""; } }))].filter(Boolean).slice(0, 30)) {
    try { const c = await gatherCookies("https://" + host + "/", tab.incognito); if (c) cookies[host] = c; } catch (e) { }
  }
  const r = await hostRequest({ type: "links", links, referrer: tab.url || "", userAgent: navigator.userAgent, cookies, selection: !!selectionOnly }, DOWNLOAD_REPLY_MS);
  if (!r || !r.ok) notify("IDMClone no disponible", r && r.error);
  return r;
}

B.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "idmclone-all" || info.menuItemId === "idmclone-selected") {
    await sendLinks(tab, info.menuItemId === "idmclone-selected");
    return;
  }
  const url = info.linkUrl || info.srcUrl;
  if (!L.isCapturableScheme(url)) { notify("IDMClone", "Ese enlace no se puede descargar (" + String(url).split(":")[0] + ")."); return; }
  const r = await sendToIdm({ url, referrer: tab ? tab.url : "", filename: "", incognito: !!(tab && tab.incognito) });
  notify(r && r.ok ? "Enviado a IDMClone" : "IDMClone no disponible", r && r.ok ? url : (r && r.error));
});

// --- Mensajes del popup ---
B.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req && req.type === "ping-host") {
    hostRequest({ type: "ping" }, PING_REPLY_MS).then(sendResponse);
    return true;
  }
  if (req && req.type === "prevent-capture" && req.url) {
    prevented.set(req.url, { t: Date.now(), referrer: req.referrer || "" });
    return false;
  }
  if (req && req.type === "force-download" && req.url) {
    const tab = sender && sender.tab;
    sendToIdm({ url: req.url, referrer: req.referrer || (tab && tab.url) || "", filename: "", incognito: !!(tab && tab.incognito) })
      .then((r) => { notify(r && r.ok ? "Enviado a IDMClone" : "IDMClone no disponible", r && r.ok ? req.url : (r && r.error)); sendResponse(r); });
    return true;
  }
  if (req && req.type === "media-download" && req.entry && req.item) {
    const tab = sender && sender.tab;
    downloadMedia(req.entry, req.item, tab).then((r) => {
      notify(r && r.ok ? "Enviado a IDMClone" : "IDMClone no disponible", r && r.ok ? ((tab && tab.title) || req.entry.url) : (r && r.error));
      sendResponse(r);
    });
    return true;
  }
  if (req && req.type === "media-options") {
    hostRequest({ type: "showoptions", tab: "General" }, DOWNLOAD_REPLY_MS).then(sendResponse);
    return true;
  }
  if (req && req.type === "get-settings") {
    appCfgAt = 0; // el popup quiere lo último
    getSettings().then(sendResponse);
    return true;
  }
  if (req && req.type === "open-options") {
    hostRequest({ type: "showoptions", tab: "Tipos de archivo" }, DOWNLOAD_REPLY_MS).then(sendResponse);
    return true;
  }
  return false;
});

// Para las pruebas con Node (no hace nada en el navegador).
if (typeof module !== "undefined" && module.exports) module.exports = { consider, hostRequest, getSettings, rememberHeaders, rememberPost, collectLinks, sendLinks, headerCache, detectMedia, downloadMedia, tabMedia, _reset: () => { decided.clear(); waitingName.clear(); appCfg = null; appCfgAt = 0; prevented.clear(); postBodies.clear(); tabMedia.clear(); } };
else {
  // Al arrancar el navegador: leer ya las teclas especiales de IDMClone para las páginas (content.js).
  setTimeout(() => { getAppConfig().catch(() => {}); }, 3000);
}
