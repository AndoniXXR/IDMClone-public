// IDMClone Integration — teclas especiales al hacer clic en un enlace (como IDM):
//   - mantener pulsada la tecla "para no descargar con IDMClone" (por defecto Supr): la descarga sigue en el navegador;
//   - mantener pulsada la tecla "para forzar la descarga" (por defecto Insert, desactivada): va a IDMClone sea del tipo que sea.
// Las teclas se eligen en IDMClone (Opciones > General). Solo mira los clics en enlaces; no lee el contenido de la página.
(() => {
  "use strict";
  const B = (typeof browser !== "undefined" && browser.runtime) ? browser : chrome;
  let keys = { prevent: "del", force: "" };   // valores de IDM hasta saber los de IDMClone
  const down = { del: false, ins: false };

  function apply(a) {
    if (a && typeof a.preventKeys === "string") keys = { prevent: a.preventKeys, force: a.forceKeys || "" };
  }
  try {
    Promise.resolve(B.storage.local.get({ appCfg: null })).then((s) => apply(s && s.appCfg)).catch(() => {});
    B.storage.onChanged.addListener((ch) => { if (ch.appCfg) apply(ch.appCfg.newValue); });
  } catch (e) { }

  addEventListener("keydown", (e) => { if (e.key === "Delete") down.del = true; if (e.key === "Insert") down.ins = true; }, true);
  addEventListener("keyup", (e) => { if (e.key === "Delete") down.del = false; if (e.key === "Insert") down.ins = false; }, true);
  // Solo cuando la ventana pierde el foco (no al pasar el foco de un enlace a otro: eso ocurre justo en el clic).
  addEventListener("blur", (e) => { if (e.target === window) down.del = down.ins = false; });

  function held(combo, e) {
    if (!combo) return false;
    return combo.split("+").every((k) =>
      k === "alt" ? e.altKey : k === "ctrl" ? e.ctrlKey : k === "shift" ? e.shiftKey : k === "del" ? down.del : k === "ins" ? down.ins : false);
  }

  function onClick(e) {
    const a = e.target && e.target.closest ? e.target.closest("a[href]") : null;
    if (!a || !/^(https?|ftps?):/i.test(a.href)) return;
    if (held(keys.force, e)) {
      e.preventDefault();
      e.stopImmediatePropagation();
      try { B.runtime.sendMessage({ type: "force-download", url: a.href, referrer: location.href }); } catch (x) { }
      return;
    }
    if (held(keys.prevent, e)) {
      try { B.runtime.sendMessage({ type: "prevent-capture", url: a.href, referrer: location.href }); } catch (x) { }
    }
  }
  addEventListener("click", onClick, true);
})();

// Panel "Descargar este video" (como el de IDM): aparece encima del reproductor cuando la página reproduce
// un vídeo o un audio que IDMClone puede bajar. Con varias calidades, el botón abre la lista para elegir.
// Lo avisa background.js (detecta las peticiones de vídeo); el panel vive en un Shadow DOM propio para que
// los estilos de la página no le afecten, y no lee nada de la página salvo dónde están sus <video>/<audio>.
(() => {
  "use strict";
  const B = (typeof browser !== "undefined" && browser.runtime) ? browser : chrome;
  const L = (typeof self !== "undefined" && self.IDMLogic) || null;
  if (!L) return;
  const entries = [];
  let host = null, root = null, closed = false, mini = false, timer = 0;

  try {
    Promise.resolve(B.storage.local.get({ appCfg: null })).then((s) => { mini = !!(s && s.appCfg && s.appCfg.mediaMini); if (host) render(); }).catch(() => {});
  } catch (e) { }

  B.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === "idm-media-remove") {
      const i = entries.findIndex((e) => e.url === msg.url);
      if (i >= 0) { entries.splice(i, 1); if (host) { if (entries.length) render(); else { host.remove(); host = null; root = null; clearInterval(timer); } } }
      return;
    }
    if (!msg || msg.type !== "idm-media" || !msg.entry) return;
    if (entries.some((e) => e.url === msg.entry.url)) return;
    entries.unshift(msg.entry);
    if (!closed) show();
  });

  // El reproductor: el <video> visible más grande (o un <audio> con controles).
  function anchor() {
    let best = null, area = 0;
    for (const el of document.querySelectorAll("video, audio")) {
      const r = el.getBoundingClientRect();
      const a = r.width * r.height;
      if (r.width < 120 || r.height < 30 || a <= area) continue;
      const st = getComputedStyle(el);
      if (st.visibility === "hidden" || st.display === "none") continue;
      best = el; area = a;
    }
    return best;
  }

  const CSS = `
    :host { all: initial; position: absolute; z-index: 2147483647; font: 12px "Segoe UI", Arial, sans-serif; }
    .status { margin-top: 3px; padding: 4px 8px; border-radius: 3px; background: #fff; color: #1b1b1b; border: 1px solid #9aa7b6; max-width: 320px;
              box-shadow: 0 2px 6px rgba(0,0,0,.3); cursor: pointer; }
    .status.ok { border-color: #2e8b3e; color: #1d6b2b; }
    .status.err { border-color: #c0392b; color: #a12a1d; }
    .bar { display: flex; align-items: stretch; border-radius: 4px; overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,.45);
           background: linear-gradient(#4a9be8, #1f63b5); color: #fff; user-select: none; }
    button { all: unset; cursor: pointer; display: flex; align-items: center; padding: 4px 7px; color: #fff; }
    button:hover { background: rgba(255,255,255,.18); }
    button:focus-visible { outline: 2px solid #fff; outline-offset: -2px; }
    .main { gap: 6px; font-weight: 600; white-space: nowrap; }
    .sep { width: 1px; background: rgba(255,255,255,.35); }
    .x { padding: 4px 6px; font-size: 13px; }
    svg { width: 16px; height: 16px; flex: none; }
    .menu { position: absolute; right: 0; top: calc(100% + 3px); min-width: 230px; max-height: 320px; overflow: auto; background: #fff; color: #1b1b1b;
            border: 1px solid #9aa7b6; border-radius: 3px; box-shadow: 0 3px 10px rgba(0,0,0,.35); padding: 3px 0; }
    .menu[hidden] { display: none; }
    .item { display: flex; justify-content: space-between; gap: 14px; width: 100%; box-sizing: border-box; padding: 5px 12px; color: #1b1b1b; }
    .item:hover, .item:focus-visible { background: #cfe3fb; outline: none; }
    .item .size { color: #5d6670; }
    .head { padding: 4px 12px 2px; color: #5d6670; font-size: 11px; }
    hr { border: 0; border-top: 1px solid #dde3ea; margin: 3px 0; }
    .note { padding: 6px 12px; color: #8a2b14; max-width: 300px; white-space: normal; }
  `;
  const ICON = '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="7.2" fill="#fff" opacity=".95"/><path d="M8 3.5v6.2M5.2 7.2 8 10l2.8-2.8M4.6 12h6.8" fill="none" stroke="#1f63b5" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  function show() {
    if (!host) {
      host = document.createElement("idmclone-panel");
      root = host.attachShadow({ mode: "open" });
      (document.body || document.documentElement).appendChild(host);
      addEventListener("scroll", place, true);
      addEventListener("resize", place);
      document.addEventListener("fullscreenchange", place);
      timer = setInterval(place, 700);
    }
    render();
    place();
  }

  function render() {
    const media = entries.some((e) => e.media === "video") ? "video" : "audio";
    const text = "Descargar este " + media;
    root.innerHTML = `<style>${CSS}</style>
      <div class="bar" role="toolbar" aria-label="Panel de descarga de IDMClone">
        <button class="main" title="${text} con IDMClone">${ICON}${mini ? "" : "<span>" + text + "</span>"}</button>
        <span class="sep"></span>
        <button class="x" title="Cerrar" aria-label="Cerrar">×</button>
      </div>
      <div class="menu" role="menu" hidden></div>`;
    root.querySelector(".main").addEventListener("click", (e) => { e.stopPropagation(); onMain(); });
    root.querySelector(".x").addEventListener("click", (e) => { e.stopPropagation(); hide(); });
  }

  function choices() {
    const out = [];
    for (const e of entries) for (const it of e.items || []) out.push({ entry: e, item: it });
    return out;
  }

  function onMain() {
    const all = choices();
    if (all.length === 1 && !all[0].entry.protected) { send(all[0]); return; }
    const menu = root.querySelector(".menu");
    if (!menu.hidden) { menu.hidden = true; return; }
    menu.innerHTML = "";
    for (const e of entries) {
      if (entries.length > 1 || e.duration > 0) {
        const h = document.createElement("div"); h.className = "head";
        h.textContent = (e.media === "audio" ? "audio" : "video") + (e.live ? ", en directo (se graba hasta que lo detengas)" : e.duration > 0 ? ", duración " + L.formatDuration(e.duration) : "");
        menu.appendChild(h);
      }
      if (e.protected) {
        const n = document.createElement("div"); n.className = "note";
        n.textContent = "IDMClone no puede descargar este contenido porque está protegido (DRM).";
        menu.appendChild(n);
        continue;
      }
      for (const it of e.items || []) {
        const b = document.createElement("button"); b.className = "item"; b.setAttribute("role", "menuitem");
        const label = L.mediaLabel(it), sep = label.indexOf("  ");
        const name = document.createElement("span"); name.textContent = sep > 0 ? label.substring(0, sep) : label;
        const size = document.createElement("span"); size.className = "size"; size.textContent = sep > 0 ? label.substring(sep + 2) : "";
        b.appendChild(name); b.appendChild(size);
        b.addEventListener("click", (ev) => { ev.stopPropagation(); menu.hidden = true; send({ entry: e, item: it }); });
        menu.appendChild(b);
      }
    }
    menu.appendChild(document.createElement("hr"));
    const about = document.createElement("button"); about.className = "item"; about.textContent = "Acerca de este panel";
    about.addEventListener("click", (ev) => {
      ev.stopPropagation(); menu.hidden = true;
      alert("Este es el panel de descarga de IDMClone.\nPuede ser personalizado o desactivado en IDMClone > Opciones > General.");
    });
    menu.appendChild(about);
    menu.hidden = false;
    const first = menu.querySelector(".item"); if (first) first.focus();
  }

  // Al elegir: se avisa en el propio panel de si IDMClone la recibió (o del motivo si no).
  function send(c) {
    status("Enviando a IDMClone...", "");
    let p;
    try { p = B.runtime.sendMessage({ type: "media-download", entry: c.entry, item: c.item }); }
    catch (e) { status("No se pudo enviar: " + (e && e.message || e) + ". Recarga la página.", "err"); return; }
    Promise.resolve(p).then((r) => {
      if (r && r.ok) status("Enviado a IDMClone", "ok");
      else status((r && r.error) || "IDMClone no respondió.", "err");
    }).catch((e) => status("No se pudo enviar: " + (e && e.message || e) + ". Si acabas de instalar o recargar la extensión, recarga la página.", "err"));
  }

  let statusTimer = 0;
  function status(text, kind) {
    if (!root) return;
    let n = root.querySelector(".status");
    if (!n) { n = document.createElement("div"); n.className = "status"; root.appendChild(n); n.addEventListener("click", () => n.remove()); }
    n.textContent = text;
    n.className = "status " + kind;
    clearTimeout(statusTimer);
    if (kind === "ok") statusTimer = setTimeout(() => { if (n.parentNode) n.remove(); }, 4000);
  }

  function hide() {
    closed = true;
    if (host) { host.remove(); host = null; root = null; }
    clearInterval(timer);
  }

  // Encima del reproductor, arriba a la derecha (como IDM); sin reproductor visible, arriba a la derecha de la ventana.
  function place() {
    if (!host) return;
    const fs = document.fullscreenElement;
    const parent = fs && fs.tagName !== "VIDEO" ? fs : (document.body || document.documentElement);
    if (host.parentNode !== parent) parent.appendChild(host);
    const a = anchor();
    const w = host.offsetWidth || 180;
    if (a && (!fs || fs.contains(a) || fs === a)) {
      const r = a.getBoundingClientRect();
      const fixed = !!fs;
      host.style.position = fixed ? "fixed" : "absolute";
      host.style.top = Math.max(0, r.top + (fixed ? 0 : scrollY) + 6) + "px";
      host.style.left = Math.max(0, r.right + (fixed ? 0 : scrollX) - w - 6) + "px";
    } else {
      host.style.position = "fixed";
      host.style.top = "8px";
      host.style.left = Math.max(0, innerWidth - w - 12) + "px";
    }
  }
})();
