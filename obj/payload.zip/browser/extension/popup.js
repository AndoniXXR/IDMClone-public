// Ajustes de la integración. Los tipos de archivo y los sitios excluidos son los de IDMClone
// (Opciones > Tipos de archivo), como en IDM; si IDMClone no responde, se editan aquí.
const L = self.IDMLogic;
const B = (typeof browser !== "undefined" && browser.runtime) ? browser : chrome;

function $(id) { return document.getElementById(id); }

let fromApp = false;

function fill(s) {
  $("enabled").checked = !!s.enabled;
  $("minSize").value = s.minSizeKB || 0;
  $("exts").value = (Array.isArray(s.exts) && s.exts.length ? s.exts : L.DEFAULT_EXTS).join(" ");
  $("exclude").value = (Array.isArray(s.exclude) ? s.exclude : L.DEFAULT_EXCLUDE).join("\n");
  fromApp = !!s.fromApp;
  $("exts").readOnly = $("exclude").readOnly = fromApp;
  $("fromApp").hidden = !fromApp;
  $("options").hidden = !fromApp;
  $("defaults").hidden = fromApp;
}

async function load() {
  let s = null;
  try { s = await B.runtime.sendMessage({ type: "get-settings" }); } catch (e) { }
  fill(s || await B.storage.local.get({ enabled: true, exts: L.DEFAULT_EXTS, minSizeKB: 0, exclude: L.DEFAULT_EXCLUDE }));
  setStatus("Listo.");
}

function setStatus(text, cls) {
  const el = $("status");
  el.textContent = text;
  el.className = "status" + (cls ? " " + cls : "");
}

$("defaults").addEventListener("click", () => {
  fill({ enabled: $("enabled").checked, minSizeKB: parseInt($("minSize").value, 10) || 0, exts: L.DEFAULT_EXTS, exclude: L.DEFAULT_EXCLUDE });
  setStatus("Valores de IDM cargados. Pulsa Guardar para aplicarlos.");
});

$("save").addEventListener("click", async () => {
  const minSizeKB = Math.max(0, parseInt($("minSize").value, 10) || 0);
  const data = { enabled: $("enabled").checked, minSizeKB };
  if (!fromApp) {
    data.exts = $("exts").value.toLowerCase().split(/[\s,;]+/).map((x) => x.replace(/^\./, "").trim()).filter(Boolean);
    data.exclude = $("exclude").value.split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
  }
  await B.storage.local.set(data);
  setStatus("Guardado.", "ok");
});

$("options").addEventListener("click", async () => {
  setStatus("Abriendo las opciones de IDMClone…");
  let r;
  try { r = await B.runtime.sendMessage({ type: "open-options" }); } catch (e) { r = { ok: false, error: String(e && e.message || e) }; }
  if (r && r.ok) { setStatus("Cambia las listas en IDMClone y vuelve a abrir este panel.", "ok"); }
  else setStatus((r && r.error) || "No se pudo abrir IDMClone.", "bad");
});

$("test").addEventListener("click", async () => {
  setStatus("Probando…");
  let r;
  try { r = await B.runtime.sendMessage({ type: "ping-host" }); }
  catch (e) { setStatus("Error: " + (e && e.message || e), "bad"); return; }
  if (!r || !r.ok) setStatus((r && r.error) || "No se pudo contactar con el host. ¿Ejecutaste install.ps1?", "bad");
  else if (r.gui) setStatus("Conectado: el host responde e IDMClone está abierto.", "ok");
  else setStatus("El host responde. IDMClone está cerrado: se abrirá solo al capturar una descarga.", "warn");
});

load();
