// IDMClone Integration — lógica de decisión (sin APIs del navegador, se prueba con Node).
// La usan background.js (service worker / página de fondo) y popup.js.
(function (root) {
  "use strict";

  // Tipos de archivo que IDM captura por defecto (Opciones -> Tipos de archivo, PDF §5.3).
  const DEFAULT_EXTS = [
    "3gp", "7z", "aac", "ace", "aif", "apk", "arj", "asf", "avi", "bin", "bz2", "exe", "gz", "gzip", "img", "iso",
    "lzh", "m4a", "m4v", "mkv", "mov", "mp3", "mp4", "mpa", "mpe", "mpeg", "mpg", "msi", "msu", "ogg", "ogv", "pdf",
    "plj", "pps", "ppt", "qt", "r0*", "r1*", "ra", "rar", "rm", "rmvb", "sea", "sit", "sitx", "tar", "tif", "tiff",
    "wav", "wma", "wmv", "z", "zip"
  ];

  // Sitios desde los que no se captura (como defexclist.txt de IDM: sonidos y vídeos de webs).
  const DEFAULT_EXCLUDE = ["*.meebo.com/*.mp3", "images.apple.com/*.mov", "*.update.microsoft.com/*"];

  // Tipo MIME -> extensión, para cuando ni la URL ni el servidor dan un nombre con extensión.
  const MIME_EXT = {
    "application/zip": "zip", "application/x-zip-compressed": "zip", "application/x-7z-compressed": "7z",
    "application/x-rar-compressed": "rar", "application/vnd.rar": "rar", "application/gzip": "gz", "application/x-gzip": "gz",
    "application/x-bzip2": "bz2", "application/x-tar": "tar", "application/x-iso9660-image": "iso",
    "application/x-msdownload": "exe", "application/x-msdos-program": "exe", "application/x-ms-installer": "msi",
    "application/x-msi": "msi", "application/vnd.android.package-archive": "apk",
    "application/pdf": "pdf", "application/vnd.ms-powerpoint": "ppt",
    "audio/mpeg": "mp3", "audio/mp3": "mp3", "audio/wav": "wav", "audio/x-wav": "wav", "audio/aac": "aac", "audio/mp4": "m4a",
    "audio/ogg": "ogg", "audio/x-ms-wma": "wma",
    "video/mp4": "mp4", "video/x-matroska": "mkv", "video/quicktime": "mov", "video/x-msvideo": "avi", "video/x-ms-wmv": "wmv",
    "video/mpeg": "mpg", "video/ogg": "ogv", "video/3gpp": "3gp",
    "application/vnd.apple.mpegurl": "m3u8", "application/x-mpegurl": "m3u8", "application/dash+xml": "mpd",
    "text/html": "html"
  };

  function extOf(name) {
    if (!name) return "";
    let q = String(name).split(/[?#]/)[0];
    q = q.replace(/\\/g, "/");
    q = q.substring(q.lastIndexOf("/") + 1);
    const dot = q.lastIndexOf(".");
    if (dot <= 0 || dot === q.length - 1) return "";
    return q.substring(dot + 1).toLowerCase();
  }

  function baseName(path) {
    if (!path) return "";
    const p = String(path).replace(/\\/g, "/");
    return p.substring(p.lastIndexOf("/") + 1);
  }

  // "r0*" captura .r00 .r01...; "mp3" solo .mp3.
  function extMatches(ext, patterns) {
    if (!ext) return false;
    ext = ext.toLowerCase();
    for (const raw of patterns || []) {
      const p = String(raw).toLowerCase().replace(/^\./, "").trim();
      if (!p) continue;
      if (p.indexOf("*") >= 0 || p.indexOf("?") >= 0) {
        const re = new RegExp("^" + p.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".") + "$");
        if (re.test(ext)) return true;
      } else if (p === ext) return true;
    }
    return false;
  }

  // Patrón de exclusión: "host/ruta" con comodines; si no lleva "/", solo el host.
  function urlExcluded(url, patterns) {
    let u;
    try { u = new URL(url); } catch (e) { return false; }
    const target = (u.host + u.pathname).toLowerCase();
    for (const raw of patterns || []) {
      let p = String(raw).trim().toLowerCase();
      if (!p) continue;
      p = p.replace(/^[a-z]+:\/\//, "");
      if (p.indexOf("/") < 0) p += "/*";
      const re = new RegExp("^" + p.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".") + "$");
      if (re.test(target)) return true;
      // "dominio.com/*" también vale para sus subdominios
      if (p.indexOf("*.") !== 0) {
        const re2 = new RegExp("^([^/]+\\.)?" + p.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".") + "$");
        if (re2.test(target)) return true;
      }
    }
    return false;
  }

  // Content-Disposition (RFC 6266 + RFC 5987), igual que en la aplicación.
  function filenameFromContentDisposition(cd) {
    if (!cd) return "";
    let plain = "", ext = "";
    const re = /(filename\*?)\s*=\s*(?:"((?:[^"\\]|\\.)*)"|([^;]*))/gi;
    let m;
    while ((m = re.exec(cd)) !== null) {
      const key = m[1].toLowerCase();
      const val = m[2] !== undefined ? m[2].replace(/\\(.)/g, "$1") : (m[3] || "").trim();
      if (key === "filename*") {
        const parts = val.split("'");
        const data = parts.length >= 3 ? parts.slice(2).join("'") : val;
        try { ext = decodeURIComponent(data); } catch (e) { ext = data; }
      } else {
        let v = val;
        if (/%[0-9a-f]{2}/i.test(v)) { try { v = decodeURIComponent(v); } catch (e) { } }
        plain = v;
      }
    }
    return baseName(ext || plain).trim();
  }

  function isCapturableScheme(url) {
    return typeof url === "string" && /^(https?|ftps?):\/\//i.test(url);
  }

  // Decide si IDMClone se queda con una descarga del navegador.
  //   d: { url, finalUrl, filename, mime, totalBytes, contentDisposition, byExtensionId }
  //   s: { enabled, exts, minSizeKB, exclude }
  // Devuelve { capture, reason, name, ext }.
  function decide(d, s) {
    const out = { capture: false, reason: "", name: "", ext: "" };
    if (!s || !s.enabled) { out.reason = "captura desactivada"; return out; }
    const url = d.finalUrl || d.url;
    if (!isCapturableScheme(url)) { out.reason = "esquema no capturable (" + String(url).split(":")[0] + ")"; return out; }
    if (d.byExtensionId && d.ownId && d.byExtensionId === d.ownId) { out.reason = "descarga propia"; return out; }
    if (urlExcluded(url, s.exclude) || (d.url && urlExcluded(d.url, s.exclude))) { out.reason = "sitio excluido"; return out; }

    // Nombre: el que decidió el navegador > Content-Disposition > URL final > URL original.
    let name = baseName(d.filename) || filenameFromContentDisposition(d.contentDisposition) || baseName(urlPath(url)) || baseName(urlPath(d.url));
    let ext = extOf(name);
    if (!ext && d.mime) ext = MIME_EXT[String(d.mime).split(";")[0].trim().toLowerCase()] || "";
    out.name = name; out.ext = ext;

    if (!extMatches(ext, s.exts && s.exts.length ? s.exts : DEFAULT_EXTS)) { out.reason = "tipo no vigilado (" + (ext || "sin extensión") + ")"; return out; }
    const min = (s.minSizeKB || 0) * 1024;
    if (min > 0 && d.totalBytes > 0 && d.totalBytes < min) { out.reason = "más pequeño que el mínimo"; return out; }
    out.capture = true;
    out.reason = "tipo vigilado (" + ext + ")";
    return out;
  }

  function urlPath(url) {
    try { return decodeURIComponent(new URL(url).pathname); } catch (e) { return ""; }
  }

  // ---- Panel "Descargar este video" (como IDM) ----
  const HLS_MIME = ["application/vnd.apple.mpegurl", "application/x-mpegurl", "audio/mpegurl", "audio/x-mpegurl", "application/mpegurl"];
  const MEDIA_EXTS = ["mp4", "m4v", "webm", "mov", "mkv", "flv", "ogv", "3gp", "mp3", "m4a", "oga", "ogg", "opus", "wav", "aac", "flac", "weba"];
  const AUDIO_EXTS = ["mp3", "m4a", "oga", "ogg", "opus", "wav", "aac", "flac", "weba"];

  // ¿Es un vídeo o un audio que el panel puede ofrecer? Los trozos que piden los reproductores por
  // JavaScript (MSE: .ts, .m4s, fragmentos por XHR) no: se ofrece la lista HLS/DASH de la que salen.
  //   d: { url, type, statusCode, contentType, contentLength, contentRange }
  // Devuelve null o { kind: "hls"|"dash"|"file", media: "video"|"audio", size }.
  function classifyMedia(d) {
    if (!d || !isCapturableScheme(d.url)) return null;
    if (d.statusCode && d.statusCode !== 200 && d.statusCode !== 206) return null;
    const ct = String(d.contentType || "").split(";")[0].trim().toLowerCase();
    const ext = extOf(urlPath(d.url) || d.url);
    if (HLS_MIME.indexOf(ct) >= 0 || ext === "m3u8") return { kind: "hls", media: "video", size: -1 };
    if (ct === "application/dash+xml" || ext === "mpd") return { kind: "dash", media: "video", size: -1 };
    if (ct === "video/mp2t" || ct === "audio/mp2t" || ct === "video/iso.segment" || ext === "ts" || ext === "m4s") return null;
    // Archivo entero que el reproductor pide a trozos (Range o ?bytestart=&byteend=, como Facebook o Instagram):
    // se ofrece el archivo completo, sin los parámetros del trozo.
    const rangeInQuery = /[?&](bytestart|byteend|range)=/i.test(d.url);
    if ((d.type === "xmlhttprequest" || d.type === "other") && (d.statusCode === 206 || rangeInQuery)) {
      const av = /^(video|audio)\//.test(ct) || (MEDIA_EXTS.indexOf(ext) >= 0 && (!ct || ct === "application/octet-stream"));
      if (!av) return null;
      const t = /\/(\d+)\s*$/.exec(String(d.contentRange || ""));
      const media = ct.indexOf("audio/") === 0 || AUDIO_EXTS.indexOf(ext) >= 0 || /[?&]mime=audio/i.test(d.url) ? "audio" : "video";
      return { kind: "file", media, size: t ? parseInt(t[1], 10) : -1, url: stripRange(d.url), ranged: true };
    }
    if (d.type !== "media" && d.type !== "object" && d.type !== "other") return null;
    const isMedia = /^(video|audio)\//.test(ct) || (MEDIA_EXTS.indexOf(ext) >= 0 && (!ct || ct === "application/octet-stream"));
    if (!isMedia) return null;
    let size = -1;
    const m = /\/(\d+)\s*$/.exec(String(d.contentRange || ""));
    if (m) size = parseInt(m[1], 10);
    else if (d.statusCode !== 206 && d.contentLength > 0) size = d.contentLength;
    const media = ct.indexOf("audio/") === 0 || AUDIO_EXTS.indexOf(ext) >= 0 ? "audio" : "video";
    return { kind: "file", media, size };
  }

  // Dirección del archivo entero: sin los parámetros que piden un trozo.
  function stripRange(url) {
    try {
      const u = new URL(url);
      let changed = false;
      for (const p of ["bytestart", "byteend", "range", "rn", "rbuf"]) if (u.searchParams.has(p)) { u.searchParams.delete(p); changed = true; }
      return changed ? u.toString() : url;
    } catch (e) { return url; }
  }

  // Nombre del archivo a partir del título de la página (como IDM).
  function mediaFileName(title, ext) {
    let t = String(title || "").replace(/[\\/:*?"<>|\u0000-\u001f]+/g, " ").replace(/\s+/g, " ").trim();
    t = t.replace(/^[. ]+|[. ]+$/g, "");
    if (t.length > 120) t = t.substring(0, 120).trim();
    if (!t) t = "video";
    if (ext && ext[0] !== ".") ext = "." + ext;
    return t + (ext || "");
  }

  function formatSize(bytes) {
    if (!(bytes > 0)) return "";
    if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(2) + " GB";
    if (bytes >= 1048576) return (bytes / 1048576).toFixed(1) + " MB";
    return Math.max(1, Math.round(bytes / 1024)) + " KB";
  }

  function formatDuration(sec) {
    sec = Math.round(sec || 0);
    if (sec <= 0) return "";
    const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
    return (h > 0 ? h + ":" + String(m).padStart(2, "0") : String(m)) + ":" + String(s).padStart(2, "0");
  }

  // Texto de cada calidad del menú del panel: "MP4 1280x720  25.3 MB" / "solo audio (es)  3.1 MB".
  function mediaLabel(item) {
    const size = formatSize(item.size);
    let t;
    if (item.kind === "audio") t = "solo audio" + (item.language ? " (" + item.language + ")" : "") + " " + String(item.ext || ".m4a").replace(".", "").toUpperCase();
    else {
      t = String(item.ext || ".mp4").replace(".", "").toUpperCase();
      if (item.height > 0) t += " " + item.width + "x" + item.height;
      else if (item.bandwidth > 0) t += " " + Math.round(item.bandwidth / 1000) + " kbps";
    }
    return size ? t + "  " + size : t;
  }

  const api = { DEFAULT_EXTS, DEFAULT_EXCLUDE, MIME_EXT, extOf, baseName, extMatches, urlExcluded, filenameFromContentDisposition, isCapturableScheme, decide,
                classifyMedia, stripRange, mediaFileName, formatSize, formatDuration, mediaLabel };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.IDMLogic = api;
})(typeof self !== "undefined" ? self : globalThis);
